# SIGAP Backend

Backend FastAPI + MySQL untuk sistem pengaduan SIGAP.

## Struktur Proyek

```
app/
  main.py            -> entry point FastAPI
  config.py          -> baca variabel dari .env
  database.py        -> koneksi SQLAlchemy + Base
  seed_kategori.py   -> script one-time isi kategori & admin percobaan
  models/            -> tabel database (SQLAlchemy)
  schemas/           -> bentuk request/response (Pydantic)
  core/security.py   -> hashing password & JWT
  routers/           -> endpoint API (auth, pengaduan, dashboard)
```

## Langkah Setup (Pertama Kali)

1. **Buat virtual environment & install dependency**
   ```bash
   python -m venv venv
   source venv/bin/activate        # Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```

2. **Siapkan database MySQL**
   ```sql
   CREATE DATABASE sigap_db CHARACTER SET utf8mb4;
   ```

3. **Salin file environment**
   ```bash
   cp .env.example .env
   ```
   Lalu edit `.env`, sesuaikan `DATABASE_URL` dengan user/password MySQL kamu,
   dan ganti `JWT_SECRET_KEY` dengan string acak yang panjang.

4. **Seed data awal (kategori + 1 akun admin percobaan)**
   ```bash
   python -m app.seed_kategori
   ```
   Ini otomatis membuat semua tabel (lewat `create_all`) sekaligus mengisi
   7 kategori resmi dan 1 akun admin percobaan untuk testing:
   `NIP: 198001012026` / `password: admin123` — **ganti setelah testing pertama.**

5. **Jalankan server**
   ```bash
   uvicorn app.main:app --reload
   ```
   Buka dokumentasi API otomatis di: http://127.0.0.1:8000/docs

## Alur Testing Manual Cepat (lewat /docs)

1. `POST /api/auth/login` -> isi `username` = NIP, `password` = password admin -> dapat `access_token`
2. Klik tombol **Authorize** di halaman `/docs`, tempel token -> semua endpoint admin bisa diakses
3. `POST /api/pengaduan` -> kirim laporan percobaan (tanpa perlu login, ini endpoint siswa)
4. `GET /api/pengaduan/{ticket_code}/status` -> cek status pakai kode tiket dari langkah 3
5. `GET /api/pengaduan` (admin) -> lihat laporan masuk
6. `PATCH /api/pengaduan/{id}/status` -> ubah status selangkah demi selangkah (tidak bisa lompat)
7. `GET /api/dashboard/summary` -> lihat ringkasan jumlah per status & kategori

## Titik Integrasi Modul AI (Belum Diimplementasikan di Scaffold Ini)

Kolom-kolom berikut sudah disiapkan di tabel `pengaduan` supaya modul AI tinggal ditempel,
tanpa perlu ubah skema lagi nanti:

- `embedding` (JSON) -> hasil vector IndoBERT
- `ai_kategori_rekomendasi_id` & `ai_confidence_score` -> hasil cosine similarity
- `cluster_label` & `is_noise` -> hasil HDBSCAN

Titik pemanggilan disarankan: di dalam `buat_pengaduan()` pada `app/routers/pengaduan.py`,
persis di bagian yang sudah ditandai komentar `NOTE: pemanggilan AI pipeline`.
Cara paling aman: bangun dulu fungsi AI di modul terpisah (mis. `app/ai/embedding.py`,
`app/ai/clustering.py`), uji standalone lewat script/notebook, baru panggil dari router
setelah hasilnya konsisten.

## Catatan State Machine Status

Status laporan wajib berurutan: `menunggu -> diverifikasi -> ditindaklanjuti -> selesai`.
Endpoint `PATCH /api/pengaduan/{id}/status` menolak (400) permintaan yang melompat tahap.
