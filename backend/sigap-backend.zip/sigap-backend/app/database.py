from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from app.config import settings

# echo=False -> ganti True kalau mau lihat query SQL di terminal saat debugging
engine = create_engine(settings.database_url, pool_pre_ping=True, echo=False)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """Dependency FastAPI: buka session DB per-request, tutup otomatis setelah selesai."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
