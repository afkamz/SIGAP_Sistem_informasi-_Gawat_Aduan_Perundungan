from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.admin import Admin
from app.schemas.auth import AdminLoginResponse
from app.core.security import verify_password, create_access_token

router = APIRouter()


@router.post("/login", response_model=AdminLoginResponse)
def login_admin(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    """
    Login admin. Gunakan field 'username' pada form untuk mengisi NIP
    (standar OAuth2PasswordRequestForm dari FastAPI memang menamainya 'username').
    """
    admin = db.query(Admin).filter(Admin.nip == form_data.username).first()

    if not admin or not verify_password(form_data.password, admin.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="NIP atau kata sandi salah",
        )

    access_token = create_access_token(data={"sub": str(admin.id)})
    return AdminLoginResponse(access_token=access_token)
