from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.pengaduan import Pengaduan
from app.models.kategori import Kategori
from app.models.admin import Admin
from app.core.security import get_current_admin

router = APIRouter()


@router.get("/summary")
def ringkasan_dashboard(
    db: Session = Depends(get_db),
    admin: Admin = Depends(get_current_admin),
):
    total = db.query(func.count(Pengaduan.id)).scalar()

    per_status = (
        db.query(Pengaduan.status, func.count(Pengaduan.id))
        .group_by(Pengaduan.status)
        .all()
    )

    per_kategori = (
        db.query(Kategori.nama, func.count(Pengaduan.id))
        .join(Pengaduan, Pengaduan.kategori_id == Kategori.id)
        .group_by(Kategori.nama)
        .all()
    )

    return {
        "total_laporan": total,
        "per_status": {status.value: jumlah for status, jumlah in per_status},
        "per_kategori": {nama: jumlah for nama, jumlah in per_kategori},
    }
