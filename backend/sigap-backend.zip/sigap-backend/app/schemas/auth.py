from pydantic import BaseModel


class AdminLoginResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class AdminOut(BaseModel):
    id: int
    nip: str
    nama: str
    jabatan: str | None = None

    class Config:
        from_attributes = True
