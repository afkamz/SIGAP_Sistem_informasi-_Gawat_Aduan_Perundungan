"""
Script one-time: isi 7 kategori resmi + satu akun admin percobaan.
Jalankan manual dari root folder: python -m app.seed_kategori
"""
from app.database import SessionLocal, Base, engine
from app.models.kategori import Kategori
from app.models.admin import Admin
from app.core.security import hash_password
import app.models  # noqa: F401

KATEGORI_RESMI = [
    "Perundungan Verbal",
    "Perundungan Fisik",
    "Perundungan Siber",
    "Kekerasan Seksual",
    "Hukuman Fisik oleh Tenaga Pendidik",
    "Kekerasan Psikis/Pengucilan Sosial",
    "Penyalahgunaan Narkoba/Rokok/Minuman Keras",
]


def run():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        # Seed kategori (idempotent — skip kalau sudah ada)
        for nama in KATEGORI_RESMI:
            ada = db.query(Kategori).filter(Kategori.nama == nama).first()
            if not ada:
                db.add(Kategori(nama=nama))
        db.commit()
        print(f"Kategori tersedia: {db.query(Kategori).count()} baris")

        # Seed 1 akun admin percobaan (idempotent)
        admin_ada = db.query(Admin).filter(Admin.nip == "198001012026").first()
        if not admin_ada:
            db.add(Admin(
                nip="198001012026",
                nama="Admin Percobaan",
                jabatan="Guru BK",
                password_hash=hash_password("admin123"),  # GANTI setelah testing pertama
            ))
            db.commit()
            print("Akun admin percobaan dibuat -> NIP: 198001012026 / password: admin123")
        else:
            print("Akun admin percobaan sudah ada, dilewati.")
    finally:
        db.close()


if __name__ == "__main__":
    run()
